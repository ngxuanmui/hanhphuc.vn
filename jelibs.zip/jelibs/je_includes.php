<?php

//configs
require_once 'je_configs.php';

//email template
require_once JPATH_ROOT . DS . 'jelibs' . DS . 'classes' . DS . 'email_template.class.php';

//util
require_once JPATH_ROOT . DS . 'jelibs' . DS . 'classes' . DS . 'util.class.php';

//upload class
require_once JPATH_ROOT . DS . 'jelibs' . DS . 'classes' . DS . 'upload.class.php';