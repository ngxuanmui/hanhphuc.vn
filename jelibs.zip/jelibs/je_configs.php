<?php

define('CFG_UPLOAD_IMAGES_PATH', JPATH_ROOT . DS . 'images');

/* for bigsale.net.vn */
//define('CFG_RECAPTCHA_PUBLIC_KEY', '6LdBNssSAAAAAOPZ642iRIOurSd1Mc4g7odq6mnA');
//define('CFG_RECAPTCHA_PRIVATE_KEY', '6LdBNssSAAAAALVZSGSnVd4XMsUrdjhy7cCT2vx1');

/* for localhost */
define('CFG_RECAPTCHA_PUBLIC_KEY', '6LdvOMsSAAAAANA--SXCJv4ZolckztwqFueHq3wn');
define('CFG_RECAPTCHA_PRIVATE_KEY', '6LdvOMsSAAAAAPSPT9vfxAQttUaxzGB7fs1NyV7C');